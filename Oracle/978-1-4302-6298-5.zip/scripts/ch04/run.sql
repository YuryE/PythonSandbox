@stats
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
!gen_load.sh
exec dbms_lock.sleep(60)
@single_load
@stop
