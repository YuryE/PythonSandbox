@demo3_run 1 plsql nosort
@demo3_run 2 plsql nosort
@demo3_run 5 plsql nosort
@demo3_run 10 plsql nosort

@demo3_run 1 proc nosort
@demo3_run 2 proc nosort
@demo3_run 5 proc nosort
@demo3_run 10 proc nosort

@demo3_run 1 plsql reverse
@demo3_run 2 plsql reverse
@demo3_run 5 plsql reverse
@demo3_run 10 plsql reverse

@demo3_run 1 proc reverse
@demo3_run 2 proc reverse
@demo3_run 5 proc reverse
@demo3_run 10 proc reverse
