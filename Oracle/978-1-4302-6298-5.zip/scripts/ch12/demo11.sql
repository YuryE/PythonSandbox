-- BINARY_FLOAT/BINARY_DOUBLE Type Syntax and Usage

select to_char( 0.3f + 0.1f, '0.99999999999999' ) from dual;
