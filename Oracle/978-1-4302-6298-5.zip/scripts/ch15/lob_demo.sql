create table lob_demo
  ( owner      varchar2(255),
    time_stamp date,
    filename   varchar2(255),
    data       blob
)
/
