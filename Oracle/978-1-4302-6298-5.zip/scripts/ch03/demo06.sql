-- Dictionary-Managed and Locally-Managed Tablespaces

create tablespace dmt
  datafile '/tmp/dmt.dbf' size 2m
  extent management dictionary;

!oerr ora 12913
